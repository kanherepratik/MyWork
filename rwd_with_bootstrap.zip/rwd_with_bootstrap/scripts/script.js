 var loc = null;
$(document).ready(function(){
    loc = 1;
    second_car();
    $("#hamburger").click(function(){

       $(".hamburger-collapse").slideToggle();
    });
    $('#quicklink').click(function(){
        $(".quick-collapse").slideToggle();
    });  
    $('.carousel').carousel({
     interval: 5000
    });
    // $('.second-carousel .go-left, .second-carousel .go-right').click(function(){
    //     $('.circle-wrap').toggleClass('next-slide');
    //     $('.winter-wrapper,.help-wrapper').toggleClass('next-slide-show');
        
    // });
   

function second_car(){  
    var goLeft = $("#mySecondCarousel .items:first-child").width();
    $('#mySecondCarousel .go-right').click(function(){ 
        if(loc < 3){
            $('#mySecondCarousel .items').animate({left:"-="+goLeft+"px"},800);
            loc++;
        }
    });
    $('#mySecondCarousel .go-left').click(function(){
        if(loc > 1){
             $('#mySecondCarousel .items').animate({left:"+="+goLeft+"px"},800);
            loc--;
        }
    });
}
});//end of document 
