(function(){
	angular.
		module('memoryGame').
		component('memoryGameComp',{
			templateUrl: 'app/memory-game/memory-game.template.html',
			controller: gameController
		});
		function gameController(gamePlay, $timeout){
			this.list = gamePlay.getTileList();
			var flip = false, num, firstTile, disableClick = false;
			this.flippedValue = [];
			this.score = 0;
			this.leftNoTile = angular.copy(gamePlay.totalTiles());
			this.checkTile = function(s){
				if(!disableClick){
					if(s.flipped){
						//if already flipped then return
						return;
					}
					else{
						//first flip the tile
						s.flipped = true;
						//then check whether first flip or second flip
						if(!flip){ 	
							//for first flip
							firstTile = s;
							flip = true;
						}
						else{
							//flip second tile to show 
							s.flipped = true;
							this.score++;
							//disable ng-click
							disableClick = true;
							$timeout(function(){
										
								//for second flip check whether they are eqaul
								if(s.img === firstTile.img)
								{
									this.leftNoTile--;
								}
								else{
									//flip back first tile
									firstTile.flipped = false;
									//flip back second tile 
									s.flipped = false;
								}
								//enable ng-click
								disableClick = false;
							},1000);
							//prepare for next round
							flip = false;
						}
					}
				}
			}
		}
})();