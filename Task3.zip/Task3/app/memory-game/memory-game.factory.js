angular.
	module('memoryGame').
	factory('gamePlay',function(){
		var Tiles = {};

		Tiles.images = ['8-ball','baked-potato','dinosaur','kronos','rocket','skinny-unicorn','that-guy','zeppelin'];
		var total_tiles, Num_Col, Num_Rows, tile_list;

		//init
		var init = function(){
			//new tile list
			tile_list = [];
			//Total Tiles
			total_tiles = Tiles.images.length;
			//cal columns
			Num_Col = Math.round(Math.sqrt(total_tiles*2));
			//calculate rows
			Num_Rows = Math.floor(Math.sqrt(total_tiles*2));
			

			createTileList();
		}

		//create a tile list having double images
		var createTileList = function(){
			Tiles.images.forEach(function(e){
				tile_list.push({img:e,flipped:false});
				tile_list.push({img:e,flipped:false});
			});	
		}

		//randomize the tile list
		var randomizeTiles = function(list){
			var m = list.length, t, i;
			while(m){
				i = Math.floor(Math.random() * m--);
				// And swap it with the current element.
				t = list[m];
				list[m] = list[i];
				list[i] = t;
			}
			return list;
		}

		//split the list into rows
		Tiles.getTileList = function(){
			var random = [], random_tile_list = [];
			random = randomizeTiles(tile_list);
			for(var i=0;i<Num_Rows;i++){
				random_tile_list.push(random.splice(0,Num_Col));
			}
			return random_tile_list;
		}

		//Return Total Number of Tiles
		Tiles.totalTiles = function(){
			return total_tiles;
		}
		init();
		return Tiles;
})