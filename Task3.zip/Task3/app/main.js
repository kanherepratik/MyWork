angular.module('memoryGameApp',[
	'memoryGame'
	]);