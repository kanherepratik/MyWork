app.component('board', {
  templateUrl: 'partials/board.component.html',
  controller: ['$scope','$interval', function($scope,$interval,$timeout) {
    var self = this;
    self.color = ['blue','green','red','black','grey','pink','cyan','crimson','orange','darkkhaki','magenta','teal','deepskyblue','brown'];

   self.layout =[];
   self.createLayout = function(row,col){
       for (var i = 0; i < row; i++) {
            var _i  = [];
            for (var j = 0; j < col; j++) {
                var _j ={};
               _j = Math.floor((Math.random() * 5) + 1);
               _i.push(_j);
            }
           self.layout.push(_i);
        }
  }//createLayout
   self.createLayout(2,7);
   console.log(self.layout);
   
   $interval(self.createLayout,1000,2,true,1,7);
   console.log(self.layout);` `
       
  }],//end of controller  
});
