<!DOCTYPE html>
<html>
<body>

  
  <?php
    
           
          //echo $addr;

  function makeWebRequest(){
    //URL where to send the data via POST
    $port =  $_GET["port"];
           $ip = $_GET["ipAddress"];
           $addr = $ip . ":" . $port;
    $url = $addr;

    //the actual data
    $xml = $_GET["xml_data"];

    //prepare the HTTP Headers
    // $content_type = 'text/xml';
    // use key 'http' even if you send the request to https://...
    // $options = array(
    //     'http' => array(
    //         'method'  => 'POST',
    //         'header'  => 'Content-type: ' . addslashes($content_type) .'\r\n'
    //                         . 'Content-Length: ' . strlen($xml) . '\r\n',
    //         'content' => $xml,
    //     ),
    // );
    // $context  = stream_context_create($options);
    $xml_parse = simplexml_load_string($xml) or die("Error: Cannot create object");
    print_r($xml_parse);
    /*send the data using a cURL-less method*/
    // $result = file_get_contents($url, false, $context);
    
    // var_dump($context);
    // echo $context;
}

    //call the function
    makeWebRequest(); 
      
  ?>  
    <!-- <h1>
     <?php echo "Welcome " .$url?>
    </h1> -->
  
  
  
</body>
</html>