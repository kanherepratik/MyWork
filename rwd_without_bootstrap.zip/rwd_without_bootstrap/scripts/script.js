
$(document).ready(function(){
    var acc = $(".accordion h4");
    var i;
    $('.drop').prepend("Board Of Directors");
for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        this.nextElementSibling.classList.toggle("show");
  }
}   

	// if($(window).width() > 1023)
 //    {
 //    	$('.user').html("Welcome Mr. John");
 //    }

    $("#hamburger").click(function(){

       $(".hamburger-collapse").toggleClass("hamburger-expand");
    });

    $('.drop-text').click(function(){
        $('.drop-down').slideToggle();

    });  
    $('.drop-down ul li a').click(function(){
        var text = $(this).text();
        $('.drop').text(text);
        $('.drop-down').toggle();
    });
    
});//end of document 
